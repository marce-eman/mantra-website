import { auth } from "@/auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import LogoutButton from "@/components/LogoutButton";

export default async function AccountLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await auth();

  // Proteksi Halaman: Jika belum login, redirect ke login page
  if (!session?.user) {
    redirect("/login");
  }

  return (
    <div className="min-h-screen bg-[#050505] text-[#ececec] pt-24 pb-16 px-6 md:px-12">
      <div className="max-w-screen-2xl mx-auto">
        <div className="mb-10">
          <h1 className="text-3xl font-light tracking-widest uppercase">
            MY ACCOUNT
          </h1>
          <p className="text-[#ececec]/50 text-xs uppercase tracking-widest mt-1">
            WELCOME BACK, {session.user.name || session.user.email}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Navigation Sidebar */}
          <div className="lg:col-span-3 space-y-2">
            <Link
              href="/account"
              className="block p-3.5 rounded-xl bg-[#111111] border border-[#1f1f1f] text-xs uppercase tracking-widest hover:border-[#ececec] transition-colors"
            >
              Profile
            </Link>
            <Link
              href="/account/orders"
              className="block p-3.5 rounded-xl bg-[#111111] border border-[#1f1f1f] text-xs uppercase tracking-widest hover:border-[#ececec] transition-colors"
            >
              Orders
            </Link>
            <Link
              href="/account/addresses"
              className="block p-3.5 rounded-xl bg-[#111111] border border-[#1f1f1f] text-xs uppercase tracking-widest hover:border-[#ececec] transition-colors"
            >
              Addresses
            </Link>
            <LogoutButton />
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-9">{children}</div>
        </div>
      </div>
    </div>
  );
}