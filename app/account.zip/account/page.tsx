import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import { revalidatePath } from "next/cache";

export default async function AccountProfilePage() {
  const session = await auth();

  if (!session?.user?.email) return null;

  // Tarik data user terbaru dari database
  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
  });

  // Fitur gaib Next.js (Server Action) untuk langsung simpan WA ke database
  async function updateWhatsApp(formData: FormData) {
    "use server";
    const newWhatsapp = formData.get("whatsapp") as string;

    if (session?.user?.email) {
      await prisma.user.update({
        where: { email: session.user.email },
        data: { whatsapp: newWhatsapp },
      });
      revalidatePath("/account"); // Refresh halaman otomatis setelah disave
    }
  }

  return (
    <div className="bg-[#111111] border border-[#1f1f1f] p-8 rounded-2xl">
      <h2 className="text-xl uppercase tracking-widest font-light mb-6">
        PROFILE DETAILS
      </h2>

      <div className="space-y-4 max-w-lg text-xs tracking-widest uppercase">
        <div className="bg-[#181818] p-4 rounded-xl border border-[#2a2a2a]">
          <span className="text-[#ececec]/40 block mb-1">Full Name</span>
          <span className="text-[#ececec] font-medium text-sm">
            {user?.name || "Not Set"}
          </span>
        </div>

        <div className="bg-[#181818] p-4 rounded-xl border border-[#2a2a2a]">
          <span className="text-[#ececec]/40 block mb-1">Email Address</span>
          <span className="text-[#ececec] font-medium text-sm">
            {user?.email || "Not Set"}
          </span>
        </div>

        {/* --- FORM UPDATE WHATSAPP --- */}
        <form action={updateWhatsApp} className="bg-[#181818] p-4 rounded-xl border border-[#2a2a2a]">
          <label className="text-[#ececec]/40 block mb-2">WhatsApp Number</label>
          <div className="flex gap-3">
            <input
              type="tel"
              name="whatsapp"
              defaultValue={user?.whatsapp || ""}
              placeholder="+62 812..."
              required
              className="w-full bg-[#111111] border border-[#2a2a2a] rounded-lg px-3 py-2 text-[#ececec] focus:outline-none focus:border-[#ececec] transition-colors"
            />
            <button
              type="submit"
              className="bg-[#ececec] text-black px-4 py-2 rounded-lg font-bold hover:bg-white transition-colors cursor-pointer"
            >
              SAVE
            </button>
          </div>
        </form>

        <div className="bg-[#181818] p-4 rounded-xl border border-[#2a2a2a]">
          <span className="text-[#ececec]/40 block mb-1">Account Role</span>
          <span className="text-emerald-400 font-medium text-sm">
            {user?.role || "CUSTOMER"}
          </span>
        </div>
      </div>
    </div>
  );
}